package dairyDemo;

import com.paper.entity.User;

public class ReflectionDemo {
    User user = new User();
}

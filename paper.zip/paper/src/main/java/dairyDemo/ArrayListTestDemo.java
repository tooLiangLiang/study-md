package dairyDemo;

import com.google.common.base.Joiner;
import com.paper.entity.User;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

public class ArrayListTestDemo {


    /**
     * @Description 创建四个学生对象并设值，保存在list集合中，模拟数据
     * @author 刘鹏博
     * @return List<Student>
     */
    public static List<User> stuList() {
        List<User> stuList = new ArrayList<User>();
        User stu1 = new User();
        stu1.setSex("张三");
        stu1.setAge(20);
        stuList.add(stu1);

        User stu2 = new User();
        stu2.setSex("李四");
        stu2.setAge(21);
        stuList.add(stu2);

        User stu3 = new User();
        stu3.setSex("王二");
        stu3.setAge(21);
        stuList.add(stu3);

        User stu4 = new User();
        stu4.setSex("张五");
        stu4.setAge(22);
        stuList.add(stu4);
        return stuList;
    }

    public static void main(String[] args) {


//        List<User> stuList = stuList();
//        List<User> userList = new ArrayList<>();
//        for (User user: stuList) {
//            if(user.getSex().equals("张五")){
//                userList.add(user);
//            }
//        }
//        if(userList.size() > 0){
//            stuList.removeAll(userList);
//        }
//
//        System.out.println(stuList);
//        // 需要筛选的条件：从stuList中筛选出年龄为21和22的学生
//        List<Integer> ageList = new ArrayList<Integer>();
//        ageList.add(21);
//        ageList.add(22);
//
//        // JDK1.8提供了lambda表达式， 可以从stuList中过滤出符合条件的结果。
//        // 定义结果集
//        List<User> result = null;
//        result = stuList.stream().filter((User s) -> ageList.contains(s.getAge()))
//                .collect(Collectors.toList());
//
//        // 打印原有stuList集合中的数据
//        System.out.println("原有stuList集合中的数据");
//        stuList.forEach((User s) -> System.out.println(s.getSex() + "--->" + s.getAge()));
//
//        // 打印过滤筛选后的result结果
//        System.out.println("过滤筛选后的result结果");
//        result.forEach((User s) -> System.out.println(s.getSex() + "--->" + s.getAge()));


        String s = "1,2,4,3";
        String[] strList = s.split(",");
        String querySql = String.format("SELECT c.classify_no,c.goods_no,m.classify_name FROM bb_mall_goods_classify_conect c,\n" +
                "bb_mall_goods_classify m where c.classify_no in %s and c.goods_no = ? \n" +
                "GROUP BY c.classify_no,c.goods_no", Joiner.on(",").join(strList));


        String delSql = String.format("delete from bb_mall_goods_classify_conect where goods_no = ? and classify_no in (%s)",Joiner.on(",").join(s.split(",")));



        System.out.println(querySql);
        System.out.println(delSql);
    }







}

package dairyDemo;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class LocalDateTimeDemo {

    //获取指定时间的指定格式
    public static String formatTime(LocalDateTime time,String pattern) {
        return time.format(DateTimeFormatter.ofPattern(pattern));
    }
    public static String formatNow(String pattern) {
        return  formatTime(LocalDateTime.now(), pattern);
    }


    public static void main(String[] args) {
        //获取当前时间的指定格式
        LocalDateTime ldt = LocalDateTime.now();
        ZonedDateTime zdt = ldt.atZone(ZoneOffset.UTC); //you might use a different zone
        String iso8601 = zdt.toString();
        System.out.println(iso8601);
    }
}

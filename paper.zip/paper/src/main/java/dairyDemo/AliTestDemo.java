package dairyDemo;

import java.math.BigDecimal;

public class AliTestDemo {

    public static void main(String args[]){
        //demo1
        int num = 2147483647 ;
        num += 2 ;
        System.out.println("demo1: "+num) ;
        //demo2
        char c = 'A' ;

        int num2 = 10 ;
        switch(c) {
            case 'B' :
                num2 ++ ;
            case 'A' :
                num2 ++ ;
            case 'Y' :
                num2 ++ ;
                break ;
            default :
                num2 -- ;
        }
        System.out.println("demo2: "+num2) ;

        //demo3
        int num3 = 50 ;
        num3 = num3 ++ * 2 ;
        System.out.println("num3: "+num3) ;

        //demo4
        int num4 = 2147483647 ;
        long temp = num4 + 2L ;
        System.out.println("num4: "+num4) ;

        if(null == Integer.valueOf(12)){

        }



        //BigDecimal
        BigDecimal b1 = BigDecimal.valueOf(9);
        BigDecimal b2 = BigDecimal.valueOf(0.1);
        BigDecimal b3 = b1.subtract(b2);
        System.out.println(b3);
    }
}

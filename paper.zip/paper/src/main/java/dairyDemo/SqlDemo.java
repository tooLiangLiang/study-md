package dairyDemo;

import com.sun.javafx.binding.StringFormatter;

import java.util.LinkedList;
import java.util.List;

public class SqlDemo {
    public static void main(String[] args){

        List<Object> paramObj = new LinkedList<>();
        paramObj.add(1);
        paramObj.add(2);
        String sql = String.format("SELECT count(*) FROM bb_mall_goods_classify_conect c where c.classify_no in (SELECT id from bb_mall_goods_classify where parent_no = ? ) and goods_no = ? ",paramObj);
        System.out.println(sql);
    }
}

package com.paper.entity;

import lombok.*;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;
import java.util.Date;

@Data
@Slf4j
@AllArgsConstructor
@NoArgsConstructor
public class Subject implements Serializable {
    int id;
    String subjectType;
    String subjectContent;
    String subjectChooseA;
    String subjectChooseB;
    String subjectChooseC;
    String subjectChooseD;
    String subjectChooseE;
    String subjectChooseF;
    String subjectStandardAnswer;
    String subjectDifficulty;
    String subjectAnlysis;
    double subjectScore;
    Date createTime;
    String createUser;
    Date updateTime;
    String updateUser;


}

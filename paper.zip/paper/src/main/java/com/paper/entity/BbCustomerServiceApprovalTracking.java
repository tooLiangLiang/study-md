package com.paper.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;

import java.time.LocalDateTime;
/**
 * @author janua
 */
@Data
@TableName("bb_customer_service_approval_tracking")
public class BbCustomerServiceApprovalTracking {
    /**售后编号*/
    @TableId
    private String customerServiceId;
    /**
     * 来源
     */
    private Integer source;
    /**
     * 操作描述
     */
    private String operateDesc;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    /**
     * 备注
     */
    private String remark;


//    public static void main(String[] args) {
//        BbCustomerServiceApprovalTracking tracking = new BbCustomerServiceApprovalTracking();
//        tracking.setCreateTime(LocalDateTime.now());
//        System.out.println(tracking);
//    }
}

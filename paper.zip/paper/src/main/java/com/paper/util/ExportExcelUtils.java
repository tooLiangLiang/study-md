package com.paper.util;

import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.OutputStream;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class ExportExcelUtils {
    /**
     * @Title: exportExcel
     * @Description: 导出Excel的方法
     * @author: evan @ 2014-01-09
     * @param workbook
     * @param sheetNum (sheet的位置，0表示第一个表格中的第一个sheet)
     * @param sheetTitle  （sheet的名称）
     * @param headers    （表格的标题）
     * @param result   （表格的数据）
     * @param out  （输出流）
     * @throws Exception
     */
    public void exportExcel(HSSFWorkbook workbook, int sheetNum,
                            String sheetTitle, String[] headers, List<List<String>> result,
                            OutputStream out) throws Exception {
        // 生成一个表格
        HSSFSheet sheet = workbook.createSheet();
        workbook.setSheetName(sheetNum, sheetTitle);
        // 设置表格默认列宽度为20个字节
//        sheet.setDefaultColumnWidth((short) 20);
        // 生成一个样式
        HSSFCellStyle style = workbook.createCellStyle();
        // 设置这些样式
        style.setFillForegroundColor(HSSFColor.PALE_BLUE.index);
        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        style.setBorderRight(HSSFCellStyle.BORDER_THIN);
        style.setBorderTop(HSSFCellStyle.BORDER_THIN);
        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        // 生成一个字体
        HSSFFont font = workbook.createFont();
        font.setColor(HSSFColor.BLACK.index);
        font.setFontHeightInPoints((short) 12);
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        // 把字体应用到当前的样式
        style.setFont(font);

        // 指定当单元格内容显示不下时自动换行
        style.setWrapText(true);

        // 产生表格标题行
        HSSFRow row = sheet.createRow(0);
        for (int i = 1; i < headers.length; i++) {
            HSSFCell cell = row.createCell((short) i);

            cell.setCellStyle(style);
            HSSFRichTextString text = new HSSFRichTextString(headers[i]);
            cell.setCellValue(text.toString());
        }
        // 遍历集合数据，产生数据行
        if (result != null) {
            int index = 1;
            for (List<String> m : result) {
                row = sheet.createRow(index);
                int cellIndex = 0;
                for (String str : m) {
                    HSSFCell cell = row.createCell((short) cellIndex);
                    cell.setCellValue(str.toString());
                    cellIndex++;
                }
                index++;
            }
        }
    }

    /**
     * 十一哥写的模板导入
     * @param list
     * @return
     */
    public static Workbook export(List<Map<String,Object>> list){
        Workbook workbook = new XSSFWorkbook();
        Font firstFont = workbook.createFont();
        firstFont.setFontName("黑体");
        firstFont.setFontHeightInPoints((short) 28);

        Font font = workbook.createFont();
        font.setFontName("黑体");
        font.setFontHeightInPoints((short) 12);

        Font endFont = workbook.createFont();
        endFont.setFontName("黑体");
        endFont.setFontHeightInPoints((short) 14);

        CellStyle firstCellStyle = workbook.createCellStyle();
        firstCellStyle.setAlignment(HorizontalAlignment.CENTER);
        firstCellStyle.setFont(firstFont);
        firstCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);

        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setAlignment(HorizontalAlignment.CENTER);
        cellStyle.setFont(font);
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);

        CellStyle endCellStyle = workbook.createCellStyle();
        endCellStyle.setAlignment(HorizontalAlignment.LEFT);
        endCellStyle.setFont(endFont);
        endCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);

        for (Map<String, Object> map : list) {
            int rowNumber = 0;
            Sheet sheet = workbook.createSheet(String.valueOf(map.get("factoryName")));
            CellRangeAddress firstCellRangeAddress = new CellRangeAddress(rowNumber,rowNumber,0,5);
            sheet.addMergedRegion(firstCellRangeAddress);
            Row firstRow = sheet.createRow(rowNumber);
            rowNumber ++ ;
            firstRow.setHeightInPoints(60);
            Cell firstCell = firstRow.createCell(0);
            firstCell.setCellStyle(firstCellStyle);
            firstCell.setCellValue("百布出货清单");

            CellRangeAddress secCellRangeAddress = new CellRangeAddress(rowNumber,rowNumber,0,5);
            sheet.addMergedRegion(secCellRangeAddress);
            Row secRow = sheet.createRow(rowNumber);
            rowNumber ++ ;
            secRow.setHeightInPoints(20);
            Cell secCell = secRow.createCell(0);
            secCell.setCellStyle(cellStyle);
            secCell.setCellValue("客户公司："+map.get("factoryName")+"                                                送货日期："+map.get("sendTime"));


            List<String> heads = (List<String>) map.get("heads");
            Row headsRow = sheet.createRow(rowNumber);
            rowNumber ++ ;
            secRow.setHeightInPoints(20);
            for (int i = 0;i<heads.size();i++) {
                sheet.setColumnWidth(i, 5000);
                Cell headsRowCell = headsRow.createCell(i);
                headsRowCell.setCellStyle(cellStyle);
                headsRowCell.setCellValue(heads.get(i));
            }


            List<Map<String,String>> data = (List<Map<String,String>>) map.get("data");
            for (int i = 0;i<data.size();i++) {
                Row dataRow = sheet.createRow(rowNumber);
                rowNumber ++ ;
                dataRow.setHeightInPoints(20);
                Iterator<Map.Entry<String, String>> iterator = data.get(i).entrySet().iterator();
                int cellNumber = 0;
                while (iterator.hasNext()){
                    Cell dataRowCell = dataRow.createCell(cellNumber);
                    cellNumber++;
                    dataRowCell.setCellStyle(cellStyle);
                    dataRowCell.setCellValue(iterator.next().getValue());
                }

                Cell headsRowCell = headsRow.createCell(i);
                headsRowCell.setCellStyle(cellStyle);
                headsRowCell.setCellValue(heads.get(i));
            }


            CellRangeAddress lastSecCellRangeAddress = new CellRangeAddress(rowNumber,rowNumber,0,5);
            sheet.addMergedRegion(lastSecCellRangeAddress);
            Row lastSecRow = sheet.createRow(rowNumber);
            rowNumber ++ ;
            lastSecRow.setHeightInPoints(20);
            Cell lastSecCell = lastSecRow.createCell(0);
            lastSecCell.setCellStyle(cellStyle);
            lastSecCell.setCellValue("出货员：                      共计条数：                           共计订单数："+map.get("sendTime"));

            CellRangeAddress endCellRangeAddress = new CellRangeAddress(rowNumber,rowNumber,0,5);
            sheet.addMergedRegion(endCellRangeAddress);
            Row endRow = sheet.createRow(rowNumber);
            endRow.setHeightInPoints(20);
            Cell endCell = endRow.createCell(0);
            endCell.setCellStyle(endCellStyle);
            endCell.setCellValue("收货人签名："+map.get("consignee"));




        }

        return workbook;
    }


}

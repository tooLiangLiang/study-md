package com.paper.util;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
     * Created by tandg on 2018/6/7.
     */
    public class ContentDispositionUtils {
    /**
     * @param request
     * @param response
     * @Title: contentDisposition
     * @Description:解决不同浏览器上文件下载的中文名乱码问题
     * @paramfilename导出/下载的文件的文件名
     */

    public static void contentDisposition(String filename, String userAgent, HttpServletRequest request, HttpServletResponse response) throws Exception {

        try {

            response.reset();

            response.setHeader("content-Type", "application/vnd.ms-excel");

            response.setCharacterEncoding("UTF-8");

            String fileName = String.format("%s - " + new SimpleDateFormat("yyyyMMddhhmmss").format(new Date()), filename) + ".xlsx";

            String newFilename = URLEncoder.encode(fileName, "UTF-8").replace("+", " ");

            String rtn = "filename=\"" + newFilename + "\"";

            if (userAgent != null) {

                userAgent = userAgent.toLowerCase();

                if (userAgent.indexOf("edge") != -1) {

                    newFilename = URLEncoder.encode(fileName, "UTF-8").replace("+", " ");

                    rtn = "filename=\"" + newFilename + "\"";

                } else if (userAgent.indexOf("trident") != -1) {

                    rtn = "filename=\"" + newFilename + "\"";

                } else {

                    rtn = "filename=\"" + new String(fileName.getBytes("UTF-8"), "ISO8859-1") + "\"";

                }

            }

            response.setHeader("Content-Disposition", "attachment;" + rtn);

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

    }
}


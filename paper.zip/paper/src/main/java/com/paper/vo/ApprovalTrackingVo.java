package com.paper.vo;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author janua
 */
@Data
public class ApprovalTrackingVo {
    /**售后编号*/
    private String customerServiceId;
    /**
     * 来源
     */
    private Integer source;
    /**
     * 操作描述
     */
    private String operateDesc;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    /**
     * 备注
     */
    private String remark;
}

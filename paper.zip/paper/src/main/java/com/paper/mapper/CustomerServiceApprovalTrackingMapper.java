package com.paper.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.paper.entity.BbCustomerServiceApprovalTracking;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author january
 */
@Mapper
public interface CustomerServiceApprovalTrackingMapper extends BaseMapper<BbCustomerServiceApprovalTracking> {


}

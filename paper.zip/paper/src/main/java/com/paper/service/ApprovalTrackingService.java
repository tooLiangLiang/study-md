package com.paper.service;

import com.paper.entity.BbCustomerServiceApprovalTracking;

/**
 * <pre>
 * *********************************************
 * Copyright BAIBU.
 * All rights reserved.
 * Description: ${添加描述}
 * HISTORY:
 * *********************************************
 *  Version       Date      Author    Desc
 *   v1.0     2019/5/30    janua  ${添加描述}
 *
 * *********************************************
 * </pre>
 */
public interface ApprovalTrackingService {
    int addApprovalTracking(BbCustomerServiceApprovalTracking tracking);
}

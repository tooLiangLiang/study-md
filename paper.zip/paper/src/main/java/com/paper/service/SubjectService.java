package com.paper.service;

import com.paper.entity.Subject;

import java.util.List;

public interface SubjectService {
    //List<Subject> getAllSubject();
}

package com.paper.service.impl;

import com.paper.entity.BbCustomerServiceApprovalTracking;
import com.paper.mapper.CustomerServiceApprovalTrackingMapper;
import com.paper.service.ApprovalTrackingService;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <pre>
 * *********************************************
 * Copyright BAIBU.
 * All rights reserved.
 * Description: ${添加描述}
 * HISTORY:
 * *********************************************
 *  Version       Date      Author    Desc
 *   v1.0     2019/5/30    janua  ${添加描述}
 *
 * *********************************************
 * </pre>
 * @author janua
 */
@Service
@Slf4j
public class ApprovalTrackingServiceImpl implements ApprovalTrackingService {
    @Resource
    private CustomerServiceApprovalTrackingMapper customerServiceApprovalTrackingMapper;
    @Override
    public int addApprovalTracking(BbCustomerServiceApprovalTracking tracking) {
        log.info("insert{}" , JSONObject.wrap(tracking));
        return customerServiceApprovalTrackingMapper.insert(tracking);
    }
}

package com.paper.service.impl;

import com.paper.service.SubjectService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
@Transactional
public class SubjectServiceImpl implements SubjectService {

}

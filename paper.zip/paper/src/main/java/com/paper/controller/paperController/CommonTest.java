package com.paper.controller.paperController;

import com.paper.entity.Subject;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CommonTest {

    public static void main(String args[]) {

//        Subject s = new Subject();
//        s.setCreateTime(new Date());
//        s.setSubjectChooseA("sfd");
//        s.setCreateUser(StringUtils.isNoneBlank(s.getSubjectChooseA())?s.getSubjectChooseA():null);
//        System.out.println(s.toString());
    }
}


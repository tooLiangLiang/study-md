package com.paper.controller;

import com.paper.entity.Subject;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.junit.Test;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@RestController
//@EnableSwagger2
//@EnableAutoConfiguration
public class SpringBootControl {

    @ApiOperation(value = "测试post请求",notes="注意事项")
    @ApiImplicitParam(dataType = "User",name = "user",value = "用户信息",required = true)
    @RequestMapping("/first")
    public String helloWord(){
        int a = 3;
        int b = 2;
        int c = a + b;
        System.out.println(c);
        return "Hello World!";
    }

//    public String TestLombok(){
//
//        Subject subject = new Subject();
//        System.out.println( subject.toString());
//        return  "";
//    }
//    @Test
//    public void testCount(){
//        helloWord();
//        TestLombok();
//       // Assert.assertNotEquals("计算成功",5,helloWord());
//    }
}

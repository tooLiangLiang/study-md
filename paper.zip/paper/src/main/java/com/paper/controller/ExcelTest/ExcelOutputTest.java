package com.paper.controller.ExcelTest;
//
//import application.ExportMoreView;
//import application.ExportView;
//import com.paper.entity.User;
//import cn.afterturn.easypoi.excel.ExcelExportUtil;
//import cn.afterturn.easypoi.excel.entity.ExportParams;
//import cn.afterturn.easypoi.excel.entity.TemplateExportParams;
//import cn.afterturn.easypoi.excel.entity.enmus.ExcelType;
//import com.paper.entity.ProductPrintInfo;
//import com.paper.entity.ShipmentOrderPrinterInfo;
//import com.paper.util.ExcelUtil;
//import org.apache.poi.ss.usermodel.Workbook;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//import javax.servlet.http.HttpServletResponse;
//import java.net.URLEncoder;
//import java.text.SimpleDateFormat;
//import java.util.*;
//
//
//@RestController
//@RequestMapping("/test/excelExport")
public class ExcelOutputTest {

//
//    @RequestMapping(value = "/excelDownload")
//    public void excelDownload( HttpServletResponse response) throws Exception{
//        ProductPrintInfo productPrintInfo = new ProductPrintInfo();
//        productPrintInfo.setClientCompany("XXXX公司");
//        productPrintInfo.setSendCargoTime(new Date());
//        productPrintInfo.setMakeNo("534");
//        productPrintInfo.setProductNo("32342");
//        productPrintInfo.setColorNo("1234");
//        productPrintInfo.setCodeOrderCount(10);
//        productPrintInfo.setSaleUnit("米");
//        productPrintInfo.setOperator("李四");
//        productPrintInfo.setCount(5);
//        productPrintInfo.setOrderCount(3);
//        List<ProductPrintInfo> list = new ArrayList<>();
//        list.add(productPrintInfo);
//        Workbook workbook = ExcelExportUtil.exportExcel(new ExportParams("111","222"),ProductPrintInfo.class,list);
//        response.setHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode(
//                new SimpleDateFormat( "yyyy-MM-dd" ).format( System.currentTimeMillis() )
//                        + "百布出货清单", "UTF-8") + ".xlsx");
//        workbook.write( response.getOutputStream() );
//    }
//
//
//    @RequestMapping("/testMoreDownload")
//    public void excelDownloadMore(HttpServletResponse response) throws Exception{
//        // 查询数据,此处省略
//        List<EasyPOIModel> list = new ArrayList<EasyPOIModel>();
//        int count1 = 0 ;
//        EasyPOIModel easyPOIModel11 = new EasyPOIModel(String.valueOf(count1++),"信科",new User("张三","男",20)) ;
//        EasyPOIModel easyPOIModel12 = new EasyPOIModel(String.valueOf(count1++),"信科",new User("李四","男",17)) ;
//
//        list.add(easyPOIModel11) ;
//        list.add(easyPOIModel12) ;
//
//        // 获取导出excel指定模版
//        TemplateExportParams params = new TemplateExportParams();
//        // 标题开始行
//        params.setHeadingStartRow(0);
//        // 标题行数
//        params.setHeadingRows(2);
//        // 设置sheetName，若不设置该参数，则使用得原本得sheet名称
//        params.setSheetName("班级信息");
//
//        params.setHeadingRows(2);
//        params.setHeadingStartRow(2);
//        params.setTempParams("t");
//        Map<String,Object> data = new HashMap<String, Object>();
//        data.put("list", list);
//
//       Workbook book = ExcelUtil.getWorkbook(params, data, "1easypoiExample.xls");
//
//        //下载
//
//        ExcelUtil.export(response, book, "easypoi-excel.xls");
//
//    }
//
//
//    @RequestMapping(value = "/moreView")
//    public void downloadMoreView(HttpServletResponse response) throws Exception{
//        List testList = new ArrayList<>();
//        List sheetsList = new ArrayList<>();
//        List<Map<String,Object>> mapList = new ArrayList<>();
//        List<ExportParams> modelList = new ArrayList<>();
//        testList.add("xx公司");
//        testList.add("xx副公司");
//        System.out.println(testList.size());
//        for (int i = 0; i< testList.size();i++){
//            ExportParams exportParams = new ExportParams();
//
//            Map<String,Object> map = new HashMap<>();
//            exportParams.setSheetName(testList.get(i).toString());
//            exportParams.setSecondTitle(testList.get(i).toString()+ URLEncoder.encode(
//                    new SimpleDateFormat( "yyyy-MM-dd" ).format( System.currentTimeMillis() )));
//            map.put("title",exportParams);
//            mapList.add(map);
//            sheetsList.add(mapList);
//
//        }
//        Workbook workbook = ExcelExportUtil.exportExcel(mapList, ExcelType.HSSF) ;
//        response.setContentType("applicationnd.ms-excel"); // 改成输出excel文件
//        String fileName = java.net.URLEncoder.encode("实收情况统计表", "UTF-8");
//        response.setHeader("Content-disposition",
//                "attachment; filename=" + fileName + ".xls");// 03版本后缀xls，之后的xlsx
//        workbook.write(response.getOutputStream());
//    }
//
//    /**
//     * 获取需要打印的内容
//     * @return
//     */
//    public ProductPrintInfo getPrintInfo(){
//        ProductPrintInfo productPrintInfo = new ProductPrintInfo();
//        productPrintInfo.setClientCompany("XXXX公司");
//        productPrintInfo.setSendCargoTime(new Date());
//        productPrintInfo.setMakeNo("534");
//        productPrintInfo.setProductNo("32342");
//        productPrintInfo.setColorNo("1234");
//        productPrintInfo.setCodeOrderCount(10);
//        productPrintInfo.setSaleUnit("米");
//        productPrintInfo.setOperator("李四");
//        productPrintInfo.setCount(5);
//        productPrintInfo.setOrderCount(3);
//        return productPrintInfo;
//    }
//
//    /**
//     * 获取头尾内容
//     * @return
//     */
//    public ShipmentOrderPrinterInfo getShipmentInfo(){
//        ShipmentOrderPrinterInfo orderPrinter = new ShipmentOrderPrinterInfo();
//        ProductPrintInfo productPrintInfo =getPrintInfo();
//        orderPrinter.setProductPrintInfo(productPrintInfo);
//        return orderPrinter;
//    }
//
//    /**
//     * 模板内容
//     * @param productPrintInfo
//     * @param orderPrinterInfo
//     * @return
//     */
//    public ExportMoreView getExportView(ProductPrintInfo productPrintInfo,ShipmentOrderPrinterInfo orderPrinterInfo){
//        ExportMoreView exportMoreView = new ExportMoreView();
//        List<ExportView> list = new ArrayList<>();
//        for (ExportView view: list) {
//            view.setCls(ProductPrintInfo.class);
//            view.setDataList(orderPrinterInfo.getShipmentOrderPrinter());
//            view.setExportParams(new ExportParams("百布","productPrintInfo.getClientCompany()"));
//            list.add(view);
//        }
//        exportMoreView.setMoreExportView(list);
//        return exportMoreView;
//    }
//
////    @RequestMapping("/test2")
////    public void excelExport(HttpServletResponse response,HttpServletRequest request) throws Exception{
////        Workbook workbook = new XSSFWorkbook();
////        ExcelExportServer server = new ExcelExportServer();
////        ProductPrintInfo productPrintInfo = new ProductPrintInfo();
////        List<ProductPrintInfo> productPrintInfos = new ArrayList<>();
//////        Map<String, Object> map = new HashMap<>();
////        ExportParams params = new ExportParams();
////        params.setTitle("证照有效期预警");
////        params.setType(ExcelType.XSSF);
////        params.setStyle(ExcelExportStylerBorderImpl.class);
////        params.setSheetName("证照有效期预警");
//////        map.put("","");
//////        Map<String, Object> map = licenseReportDao.reportChartDataByInvalidWarn(beginDateTime, endDateTime, department,
//////                company, licenseType, degreeControl);
////        server.createSheet(workbook, params, ProductPrintInfo.class, productPrintInfos);
////        ContentDispositionUtils.contentDisposition("证照有效期预警",request.getHeader("USER-AGENT"),request,response);
////        workbook.write(response.getOutputStream());
////    }
//
//
}

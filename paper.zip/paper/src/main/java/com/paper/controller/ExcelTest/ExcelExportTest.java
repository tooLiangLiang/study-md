package com.paper.controller.ExcelTest;

//import cn.afterturn.easypoi.excel.ExcelExportUtil;
//import cn.afterturn.easypoi.excel.entity.ExportParams;
//import org.apache.poi.ss.usermodel.Workbook;
//import org.jeecgframework.poi.excel.ExcelExportUtil;
//import org.jeecgframework.poi.excel.entity.ExportParams;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RestController
@EnableAutoConfiguration
@RequestMapping(value = "/jee/test")
public class ExcelExportTest {

    @RequestMapping("/excelExport")
    public void excelExportTest(HttpServletRequest request, HttpServletResponse response) throws Exception {
//
//        ProductPrintInfo productPrintInfo = new ProductPrintInfo();
//        productPrintInfo.setClientCompany("XXXX公司");
//        productPrintInfo.setSendCargoTime(new Date());
//        productPrintInfo.setMakeNo("534");
//        productPrintInfo.setProductNo("32342");
//        productPrintInfo.setColorNo("1234");
//        productPrintInfo.setCodeOrderCount(10);
//        productPrintInfo.setSaleUnit("米");
//        productPrintInfo.setOperator("李四");
//        productPrintInfo.setCount(5);
//        productPrintInfo.setOrderCount(3);
//        List<ProductPrintInfo> list = new ArrayList<>();
//        list.add(productPrintInfo);
//        Workbook workbook = ExcelExportUtil.exportExcel(new ExportParams("111","222"),ProductPrintInfo.class,list);
//        response.setHeader("Content-Disposition","123.xlsx");
//        response.setHeader("","attachment;file");
////        response.setHeader("Content-Disposition", "attachment; filename=" + "百布出货清单", "UTF-8" + ".xlsx");
//        workbook.write( response.getOutputStream() );
    }
}

package com.paper.controller.ExcelTest;

import com.paper.util.ExportExcelUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
@RestController
@RequestMapping("/test/poi")
public class ExcelPoiExportTest {

    @RequestMapping("/moreTest")
    public void test(){
        try {

            List<List<String>> data = new ArrayList<List<String>>();
            String[] headers = { "ID", "用户名" };
//            String[] headers1 = {"pic 百布出货清单"};
            String [] headers2 = {"制单号","货号","色号","码单数","单位","百布流水号"};
            ExportExcelUtils eeu = new ExportExcelUtils();
            HSSFWorkbook workbook = new HSSFWorkbook();
            int count = 1;
            OutputStream out = new FileOutputStream("D:\\test"+ count++ +".xls");
            eeu.exportExcel(workbook, 0, "上海", headers2, data, out);
            eeu.exportExcel(workbook, 1, "深圳", headers, data, out);
            eeu.exportExcel(workbook, 2, "广州", headers, data, out);
            //原理就是将所有的数据一起写入，然后再关闭输入流。
            workbook.write(out);
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}

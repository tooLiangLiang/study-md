package com.paper.controller.ExcelTest;

import com.paper.util.ExportExcelUtils;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.File;
import java.io.FileOutputStream;
import java.util.*;

public class MorePoiTest {
    public static void main(String[] args) throws Exception{

        File outFile = new File("E:\\january\\导出模板.xlsx");
        FileOutputStream fos = new FileOutputStream(outFile);

        List<Map<String,Object>> list = new ArrayList<>();
        List<String> heads = new ArrayList<>();
        heads.add("制单号");
        heads.add("货号");
        heads.add("色号");
        heads.add("码单数");
        heads.add("单位");
        heads.add("百布流水号");

//        Map<String,Object> map1 = new HashMap<>();
//        map1.put("factoryName","测试1");
//        map1.put("heads",heads);
//
//        Map<String,Object> map2 = new HashMap<>();
//        map2.put("factoryName","测试2");
//        map2.put("heads",heads);
//
//        list.add(map1);
//        list.add(map2);

        Workbook export = ExportExcelUtils.export(list);
        export.write(fos);
    }
}

package com.paper.controller.ExcelTest;

import com.paper.entity.User;

public class EasyPOIModel {
    public EasyPOIModel(String s, String s2, User user) {
    }
}

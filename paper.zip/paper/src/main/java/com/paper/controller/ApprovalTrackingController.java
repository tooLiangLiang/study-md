package com.paper.controller;

import com.paper.entity.BbCustomerServiceApprovalTracking;
import com.paper.service.ApprovalTrackingService;
import com.paper.vo.ApprovalTrackingVo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

/**
 * @author janua
 */
@RestController
@RequestMapping("/approvalTracking")
public class ApprovalTrackingController {

    @Autowired
    private ApprovalTrackingService approvalTrackingService;

    @RequestMapping("/add")
    public int addTracking(ApprovalTrackingVo trackingVo){
        trackingVo.setCreateBy("testJ");
        trackingVo.setCreateTime(LocalDateTime.now());
        trackingVo.setCustomerServiceId("123");
        trackingVo.setRemark("remark");
        BbCustomerServiceApprovalTracking tracking = new BbCustomerServiceApprovalTracking();
        BeanUtils.copyProperties(trackingVo,tracking);
        int i = 0;
        try{
            i = approvalTrackingService.addApprovalTracking(tracking);
        }catch (Exception e){

        }
        return i;
    }
}

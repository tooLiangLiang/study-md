package com.paper.controller.paperController;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RestController;

import java.text.SimpleDateFormat;
import java.util.*;

@RestController
@Slf4j
public class SubjectController {



//    public static  void main(String [] args){
//
//        StringBuilder sb = new StringBuilder();
//        sb.append(" where t.is_shipment = 0  and t.create_time >= date_sub(now(),interval 366 day)   and t.order_id in ( 20181210100014, 20181210100013, 20181210100012, 20181210100011, 20181210100010, 20181210100009, 20181210100008, 20181210100007, 20181210100006, 20181210100005, 20181210100004, 20181210100003, 20181210100002, 20181210100001, 20181210100000, 20181208100029, 20181129100005, 20181129100004, 20181129100003, 20181129100000, 20181128100016 )");
//       // sb.append("and t.create_time < ?");
//        System.out.println("截取前： "+sb.toString());
//
//        String conditonString = sb.toString();
//        String removeStart = conditonString.replaceAll(" and t.create_time >= date_sub\\(now\\(\\),interval 366 day\\)","");
//        String removeEnd = removeStart.replaceAll("and t.create_time < now\\(\\)","");
//        sb.delete(0,sb.length());
//        sb.append(removeEnd);
//        System.out.println(sb);
//
//        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
//        Calendar c = Calendar.getInstance();
//        c.setTime(new Date());
//        c.add(Calendar.YEAR, -1);
//        Date y = c.getTime();
//        String year = format.format(y);
//        System.out.println("过去一年："+year);
//
//
//        List<String> orderIDs = new ArrayList<>();
//        Map<String,Object> map = getOrderID(orderIDs);
//        System.out.println("map: "+map.get("orderId").toString());
//
//    }
//
//    public static Map<String,Object> getOrderID(List<String> orderID){
//        StringBuilder builder = new StringBuilder();
//        for (String orderIDList:orderID) {
//            builder.append(orderIDList+",");
//        }
//        String orderIDs = "";
//        if(builder.length() > 0){
//            orderIDs  = builder.substring(0,builder.length()-1);
//        }
//        System.out.println("orderIDs: " + orderIDs);
//        Map<String,Object> map = new HashMap<>();
//        map.put("orderId",orderIDs);
//        return map;
//    }
}

package application;



public class MybatisConfig {


}

package test;


import com.paper.SpringBootStartApplication;
        import org.junit.Test;
        import org.junit.runner.RunWith;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.boot.test.context.SpringBootTest;
        import org.springframework.boot.test.web.client.TestRestTemplate;
        import org.springframework.http.HttpEntity;
        import org.springframework.http.HttpHeaders;
        import org.springframework.http.HttpMethod;
        import org.springframework.http.MediaType;
        import org.springframework.http.ResponseEntity;
        import org.springframework.test.context.junit4.SpringRunner;
        import org.springframework.util.LinkedMultiValueMap;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,classes = SpringBootStartApplication.class)
public class ControllerTest {

    @Autowired
    private TestRestTemplate testRestTemplate;

    @Test
    public void logon() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        LinkedMultiValueMap<String, String> body = new LinkedMultiValueMap<>();
        body.add("username", "");
        body.add("password", "");
        HttpEntity<Object> entity = new HttpEntity<Object>(body, headers);
        ResponseEntity<String> result = testRestTemplate.exchange("/first", HttpMethod.POST, entity, String.class);
        System.out.println(" ----- " + result.getBody());
    }
}
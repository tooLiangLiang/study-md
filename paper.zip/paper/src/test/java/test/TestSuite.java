package test;

import junit.framework.Test;
import junit.framework.TestResult;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({JunitTest1.class,JunitTest2.class,JunitTest3.class})
public class TestSuite extends Object implements Test {
    public TestSuite(Class<JunitTest> junitTestClass, Class<JunitTest1> JunitTest2) {
    }

    @Override
    public int countTestCases() {
        return 0;
    }

    @Override
    public void run(TestResult result) {
        System.out.println("TEST");
    }
}

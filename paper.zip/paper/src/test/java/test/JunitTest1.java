package test;


import org.junit.Test;
import static org.junit.Assert.*;

public class JunitTest1 {
    @Test
    public void testAdd(){
        String str = "This is Me" ;
        int num = 5 ;

        assertEquals("This is Me", str);

        assertFalse(num > 6);

        assertNotNull(str);

    }
}

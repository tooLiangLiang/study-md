package test;

import junit.framework.TestResult;

public class JunitSuiteTest {

    public static void main(String[] args){

        TestSuite suite = new TestSuite(JunitTest.class,JunitTest1.class);
        TestResult result = new TestResult();
        suite.run(result);
        System.out.println(result.runCount());
    }

}

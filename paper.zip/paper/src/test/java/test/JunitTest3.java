package test;

import junit.framework.AssertionFailedError;
import junit.framework.TestResult;
import org.junit.Test;

public class JunitTest3 extends TestResult {

    //add the error
    public synchronized void addError(Test test, Throwable throwable){
        super.addError((junit.framework.Test)test,throwable);
    }

    //add the failure
    public synchronized void addFailure(Test test, AssertionFailedError assertionFailedError){
        super.addFailure((junit.framework.Test)test,assertionFailedError);
    }

    @Test
    public void testAdd(){
        // any test
    }

    //Markers that the test run should stop
    public synchronized void stop(){
        //stop here
    }
}

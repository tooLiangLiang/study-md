package test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static junit.framework.TestCase.assertEquals;


//@RunWith(SpringRunner.class)
//@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class JunitTest {



    String message = "Hello world!";

    MessageTestUtil messageTestUtil = new MessageTestUtil(message);
    @Test
    public void testPrintMessage(){
        assertEquals(message,messageTestUtil.printMessage());
    }

}

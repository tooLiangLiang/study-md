package test;

import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;

public class JunitTest2 extends TestCase {

    protected double var1 = 0.2;
    protected double var2 = 0.5;

    @Before

    public void setUp(){
        var1 = 1.5;
        var2 = 2.1;
    }

    @Test
    public void testAdd(){
        System.out.println("count the number of test cases = "+this.countTestCases());
        System.out.println("test getName = "+this.getName());
        this.setName("newAddName");
        String newName = this.getName();
        System.out.println("test getNewName: "+newName);
    }
    //tearDown used to close the connection or clean up activities
    public void tearDown(  ) {
    }
}
